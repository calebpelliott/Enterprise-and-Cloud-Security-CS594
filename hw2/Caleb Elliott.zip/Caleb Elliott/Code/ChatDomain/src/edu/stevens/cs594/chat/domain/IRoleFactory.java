package edu.stevens.cs594.chat.domain;

public interface IRoleFactory {
	
	public Role createRole();

}
