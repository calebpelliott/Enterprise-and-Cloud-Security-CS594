package edu.stevens.cs594.chat.service.ejb;

import javax.ejb.Remote;

@Remote
public interface IMessageServiceRemote extends IMessageService {

}
