package edu.stevens.cs594.chat.service.ejb;

import javax.ejb.Local;

@Local
public interface IMessageServiceLocal extends IMessageService {

}
